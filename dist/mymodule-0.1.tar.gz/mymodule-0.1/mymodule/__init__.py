# __init__.py
from .mymodule import greet, add
